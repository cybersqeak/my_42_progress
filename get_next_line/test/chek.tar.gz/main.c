#include "get_next_line.h"
#include <fcntl.h>
int main() {
int	fd = open("foo.txt", O_RDONLY);
char *test1 = get_next_line(fd);
printf("%d\n",printf("%s",test1));
free(test1);
char *test2 = get_next_line(fd);
printf("%d\n",printf("%s",test2));
free(test2);


	return 0;
}
